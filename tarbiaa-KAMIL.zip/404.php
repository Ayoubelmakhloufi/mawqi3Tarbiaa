<?php
require __DIR__ . '/partials/lib.php';

http_response_code(404);

$meta = [
    'title'       => 'الصفحة غير موجودة',
    'description' => 'الصفحة التي تبحث عنها غير متوفرة. تصفّح أقسام منصة تربية أو ابحث في الموقع.',
    'canonical'   => '/404',
    'noindex'     => true,
];

require __DIR__ . '/partials/header.php';
?>

<div class="container mx-auto px-4 md:px-6 py-16 md:py-24">
  <div class="max-w-2xl mx-auto text-center">
    <p class="text-7xl md:text-9xl font-black text-primary/10 leading-none mb-4">404</p>
    <h1 class="text-3xl md:text-4xl font-black text-primary mb-4">هذه الصفحة غير موجودة</h1>
    <p class="text-slate-500 text-lg leading-relaxed mb-10">
      ربما تغيّر الرابط أو حُذفت الصفحة. لا بأس — إليك أهم الوجهات في الموقع.
    </p>

    <div class="flex flex-wrap justify-center gap-3 mb-12">
      <a href="/" class="bg-primary text-white px-6 py-3.5 rounded-xl font-bold hover:bg-secondary transition-colors shadow-lg shadow-primary/20">الصفحة الرئيسية</a>
      <a href="/baht/" class="bg-slate-100 text-slate-700 px-6 py-3.5 rounded-xl font-bold hover:bg-slate-200 transition-colors">البحث في الموقع</a>
      <a href="/tatbiq/" class="bg-slate-100 text-slate-700 px-6 py-3.5 rounded-xl font-bold hover:bg-slate-200 transition-colors">تطبيق تربية</a>
    </div>

    <div class="grid gap-3 sm:grid-cols-2 text-right">
      <?php foreach (tb_sections() as $section): $t = tb_tint($section['tint']); ?>
      <a href="<?= e(tb_section_url($section['slug'])) ?>"
         class="flex items-center gap-3 bg-white ring-1 ring-slate-200/80 rounded-2xl p-4 hover:ring-primary/30 hover:shadow-md transition-all">
        <span class="w-10 h-10 shrink-0 rounded-xl <?= e($t['bg']) ?> <?= e($t['text']) ?> flex items-center justify-center">
          <i class="fas <?= e($section['icon']) ?>"></i>
        </span>
        <span class="font-bold text-slate-700 text-sm"><?= e($section['nav']) ?></span>
      </a>
      <?php endforeach; ?>
    </div>
  </div>
</div>

<?php require __DIR__ . '/partials/footer.php'; ?>
