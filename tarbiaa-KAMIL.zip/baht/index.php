<?php
require __DIR__ . '/../partials/lib.php';
require_once __DIR__ . '/../partials/card.php';

$all = tb_articles();

$meta = [
    'title'       => 'البحث في الموقع',
    'description' => 'ابحث في كل مقالات منصة تربية: مباراة التعليم، الإجازة في التربية والمدارس العليا، التعليم الرقمي، دروس علوم التربية والديداكتيك والمكتبة الرقمية.',
    'canonical'   => '/baht/',
    'breadcrumb'  => [['name' => 'البحث في الموقع', 'url' => '/baht/']],
    'noindex'     => true, // صفحة أداة لا محتوى فريد — نمنع فهرستها ونُبقي على تتبع الروابط
];

require __DIR__ . '/../partials/header.php';
?>

<section class="bg-white border-b border-slate-200">
  <div class="container mx-auto px-4 md:px-6 py-10 md:py-14">
    <div class="max-w-2xl">
      <h1 class="text-3xl md:text-4xl font-black text-primary mb-3">البحث في الموقع</h1>
      <p class="text-slate-500 text-lg mb-7">اكتب كلمة مفتاحية لتصفية المقالات فورًا — بدون انتظار.</p>

      <div class="relative">
        <i class="fas fa-magnifying-glass absolute right-5 top-1/2 -translate-y-1/2 text-slate-400" aria-hidden="true"></i>
        <label for="search-input" class="sr-only">ابحث في مقالات الموقع</label>
        <input type="search" id="search-input" autocomplete="off"
               placeholder="مثال: بيداغوجيا الكفايات، معدل الانتقاء، التقويم…"
               class="w-full rounded-2xl border-2 border-slate-200 bg-white pr-14 pl-5 py-4 text-lg font-medium text-slate-800 focus:border-accent focus:ring-4 focus:ring-accent/10 outline-none transition">
      </div>
      <p id="search-count" class="mt-4 text-sm font-bold text-slate-400" role="status" aria-live="polite"></p>
    </div>
  </div>
</section>

<div class="container mx-auto px-4 md:px-6 py-12 md:py-16">
  <?php if (!$all): ?>
    <div class="grid"><?php tb_empty_state('الموقع'); ?></div>
  <?php else: ?>
    <div id="search-results" class="grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
      <?php foreach ($all as $a):
          $sec  = tb_section($a['section'] ?? '');
          $hay  = implode(' ', array_filter([
              $a['title'] ?? '',
              $a['description'] ?? '',
              $sec['title'] ?? '',
              $sec['nav'] ?? '',
              implode(' ', $a['tags'] ?? []),
          ])); ?>
      <div data-haystack="<?= e($hay) ?>"><?php tb_card($a); ?></div>
      <?php endforeach; ?>
    </div>

    <div id="search-empty" hidden class="bg-white rounded-3xl ring-1 ring-slate-200/80 p-10 md:p-14 text-center mt-2">
      <div class="w-16 h-16 mx-auto rounded-2xl bg-slate-100 text-slate-400 flex items-center justify-center text-2xl mb-5">
        <i class="fas fa-magnifying-glass"></i>
      </div>
      <h2 class="text-xl font-black text-slate-800 mb-2">لا توجد نتائج مطابقة</h2>
      <p class="text-slate-500 max-w-md mx-auto leading-relaxed mb-7">
        جرّب كلمة مفتاحية أقصر أو مختلفة، أو تصفّح الأقسام مباشرة.
      </p>
      <div class="flex flex-wrap justify-center gap-3">
        <?php foreach (tb_sections() as $s): ?>
        <a href="<?= e(tb_section_url($s['slug'])) ?>" class="bg-slate-100 text-slate-700 px-4 py-2.5 rounded-xl font-bold text-sm hover:bg-slate-200 transition-colors"><?= e($s['nav']) ?></a>
        <?php endforeach; ?>
      </div>
    </div>
  <?php endif; ?>
</div>

<?php require __DIR__ . '/../partials/footer.php'; ?>
