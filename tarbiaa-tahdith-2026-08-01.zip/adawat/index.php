<?php
require __DIR__ . '/../partials/lib.php';

$sectionSlug = 'adawat';

$sectionIntro = <<<'HTML'
<p>
  أدوات مجانية تعمل مباشرة من المتصفح، بدون تسجيل ولا تثبيت، ودون أن تغادر معطياتك جهازك.
  صُممت لتوفّر عليك الحسابات اليدوية والأخطاء التي ترافقها، وتمنحك في المقابل نتيجة واضحة
  مع <b>تفصيل كامل لكل خطوة</b> حتى تفهم كيف تكوّنت.
</p>
HTML;

/* بطاقات الأدوات — تُعرض قبل قائمة المقالات */
$sectionExtra = <<<'HTML'
<section class="pb-14 md:pb-20 bg-white">
  <div class="container mx-auto px-4 md:px-6">
    <h2 class="text-2xl md:text-3xl font-black text-slate-900 mb-8">الأدوات المتاحة</h2>
    <div class="grid gap-6 md:grid-cols-2">

      <a href="/حساب_معدل_الانتقاء"
         class="group flex flex-col bg-white rounded-3xl ring-1 ring-slate-200/80 p-7 hover:ring-primary/30 hover:shadow-xl hover:-translate-y-1 transition-all duration-300">
        <span class="w-12 h-12 rounded-2xl bg-rose-50 text-rose-700 ring-1 ring-rose-200 flex items-center justify-center text-xl mb-5">
          <i class="fas fa-calculator"></i>
        </span>
        <h3 class="text-xl font-black text-slate-900 mb-2 group-hover:text-primary transition-colors">حاسبة معدل الانتقاء</h3>
        <p class="text-slate-500 leading-relaxed mb-6 flex-1">
          للمدارس العليا للأساتذة (ENS · ESEF · FSE): اختر التخصص والشعبة، أدخل نقطتَي الوطني والجهوي،
          واحصل على معدل الانتقاء التمهيدي مع خطوات الحساب وجدول المعاملات الرسمي.
        </p>
        <span class="inline-flex items-center gap-2 text-primary font-bold group-hover:gap-3 transition-all">
          افتح الحاسبة <i class="fas fa-arrow-left text-xs"></i>
        </span>
      </a>

      <a href="/hisab-intiqa-crmef"
         class="group flex flex-col bg-white rounded-3xl ring-1 ring-slate-200/80 p-7 hover:ring-primary/30 hover:shadow-xl hover:-translate-y-1 transition-all duration-300">
        <span class="w-12 h-12 rounded-2xl bg-indigo-50 text-indigo-700 ring-1 ring-indigo-200 flex items-center justify-center text-xl mb-5">
          <i class="fas fa-chalkboard-user"></i>
        </span>
        <h3 class="text-xl font-black text-slate-900 mb-2 group-hover:text-primary transition-colors">حاسبة الانتقاء الأولي — المراكز الجهوية</h3>
        <p class="text-slate-500 leading-relaxed mb-6 flex-1">
          لمباراة الولوج إلى CRMEF: احسب نقطتك على 80 من ميزة الباكالوريا والإجازة والسن،
          وقارنها بعتبات دورة نونبر 2025 حسب تخصصك.
        </p>
        <span class="inline-flex items-center gap-2 text-primary font-bold group-hover:gap-3 transition-all">
          افتح الحاسبة <i class="fas fa-arrow-left text-xs"></i>
        </span>
      </a>

      <!-- ring-dashed لا وجود لها في Tailwind (الحلقة ظلّ لا إطار) فأُزيلت -->
      <div class="flex flex-col bg-slate-50 rounded-3xl ring-1 ring-slate-300 p-7">
        <span class="w-12 h-12 rounded-2xl bg-white text-slate-400 ring-1 ring-slate-200 flex items-center justify-center text-xl mb-5">
          <i class="fas fa-screwdriver-wrench"></i>
        </span>
        <h3 class="text-xl font-black text-slate-700 mb-2">أدوات قادمة</h3>
        <p class="text-slate-500 leading-relaxed mb-6 flex-1">
          نعمل على حاسبات إضافية تخدم المترشح والأستاذ. إن كانت لديك فكرة أداة تحتاجها فعلًا،
          راسلنا ولنبنِها معًا.
        </p>
        <a href="mailto:support@tarbiaa.ma?subject=اقتراح%20أداة%20جديدة"
           class="inline-flex items-center gap-2 text-slate-600 font-bold hover:text-primary transition-colors">
          اقترح أداة <i class="fas fa-arrow-left text-xs"></i>
        </a>
      </div>

    </div>
  </div>
</section>
HTML;

$sectionFaq = [
    [
        'q' => 'هل نتيجة الحاسبة رسمية؟',
        'a' => '<p>لا. الحاسبة <b>أداة مساعدة تقريبية</b> تطبّق الصيغة المعتمدة، لكن معاملات الترجيح والعتبات قد تتغيّر من سنة إلى أخرى. طابق دائمًا المعامل مع الجدول الرسمي ومع بلاغ المباراة قبل اعتماد أي نتيجة.</p>',
    ],
    [
        'q' => 'هل تُحفظ معطياتي عند استعمال الحاسبة؟',
        'a' => '<p>لا. الحساب يتم بالكامل <b>داخل متصفحك</b>، ولا تُرسل نقطك ولا اختياراتك إلى أي خادم، ولا تُخزَّن بعد إغلاق الصفحة.</p>',
    ],
    [
        'q' => 'هل تعمل الأدوات على الهاتف؟',
        'a' => '<p>نعم، جميع الأدوات مصممة لتعمل على الهاتف واللوح والحاسوب دون فرق. ولا تحتاج إلى تثبيت أي برنامج.</p>',
    ],
];

require __DIR__ . '/../partials/section-page.php';
