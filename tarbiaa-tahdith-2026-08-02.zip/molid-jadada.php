<?php
/**
 * مولّد جذاذة درس — أداة تعمل بالكامل داخل المتصفح.
 *
 * يملأ الأستاذ الحقول فتتكوّن أمامه جذاذة منسّقة جاهزة للطباعة أو الحفظ PDF.
 * لا تُرسَل أي بيانات إلى الخادم ولا تُخزَّن.
 *
 * الطباعة تعتمد قواعد @media print الموجودة في الـCSS المُصرَّف:
 * تُخفي الهيدر والفوتر ومسار التصفح وكل ما عليه .no-print.
 */

require __DIR__ . '/partials/lib.php';

$meta = [
    'title'       => 'مولّد جذاذة درس — املأ واطبع جذاذتك جاهزة',
    'description' => 'أداة مجانية لإعداد جذاذة درس منسّقة: الكفاية والأهداف والمتطلبات القبلية '
                   . 'ومراحل الدرس والتقويم، جاهزة للطباعة. تعمل داخل متصفحك بلا تسجيل.',
    'canonical'   => '/molid-jadada',
    'image'       => '/assets/img/og-default.jpg',
    'section'     => 'adawat',
    'breadcrumb'  => [
        ['name' => 'الأدوات والحاسبات', 'url' => '/adawat/'],
        ['name' => 'مولّد جذاذة درس', 'url' => '/molid-jadada'],
    ],
    'jsonld'      => [[
        '@context'    => 'https://schema.org',
        '@type'       => 'WebApplication',
        'name'        => 'مولّد جذاذة درس',
        'url'         => tb_abs('/molid-jadada'),
        'applicationCategory' => 'EducationalApplication',
        'operatingSystem'     => 'أي متصفح',
        'inLanguage'  => 'ar',
        'offers'      => ['@type' => 'Offer', 'price' => '0', 'priceCurrency' => 'MAD'],
        'publisher'   => ['@id' => SITE_URL . '/#organization'],
    ]],
];

require __DIR__ . '/partials/header.php';
?>

<section class="gradient-bg relative overflow-hidden no-print">
  <div class="absolute inset-0 opacity-10" aria-hidden="true">
    <div class="absolute top-0 right-0 w-96 h-96 bg-accent rounded-full blur-3xl -translate-y-1/2 translate-x-1/2"></div>
  </div>
  <div class="container mx-auto px-4 md:px-6 py-10 md:py-14 relative z-10">
    <nav aria-label="مسار التصفح" class="mb-5">
      <ol class="flex flex-wrap items-center gap-2 text-sm font-bold text-white/50">
        <li><a href="/" class="hover:text-accent transition-colors">الرئيسية</a></li>
        <li aria-hidden="true"><i class="fas fa-angle-left text-[10px]"></i></li>
        <li><a href="/adawat/" class="hover:text-accent transition-colors">الأدوات</a></li>
        <li aria-hidden="true"><i class="fas fa-angle-left text-[10px]"></i></li>
        <li class="text-white/80" aria-current="page">مولّد الجذاذة</li>
      </ol>
    </nav>
    <div class="max-w-3xl text-white">
      <h1 class="text-3xl md:text-4xl font-black leading-tight mb-3">مولّد جذاذة درس</h1>
      <p class="text-lg text-slate-300 leading-relaxed mb-5">
        املأ الحقول وستتكوّن أمامك <b>جذاذة منسّقة</b> جاهزة للطباعة أو الحفظ بصيغة PDF.
        المراحل الأربع مقترحة سلفًا — عدّلها أو احذفها أو أضف غيرها.
      </p>
      <div class="flex flex-wrap gap-3 text-sm font-bold">
        <span class="inline-flex items-center gap-2 bg-white/10 text-accent rounded-xl px-4 py-2.5"><i class="fas fa-print"></i> طباعة مباشرة</span>
        <span class="inline-flex items-center gap-2 bg-white/10 text-accent rounded-xl px-4 py-2.5"><i class="fas fa-lock"></i> لا تُرسَل بياناتك</span>
        <span class="inline-flex items-center gap-2 bg-white/10 text-accent rounded-xl px-4 py-2.5"><i class="fas fa-bolt"></i> بلا تسجيل</span>
      </div>
    </div>
  </div>
</section>

<div class="bg-slate-50 py-10 md:py-14" x-data="jadada()">
  <div class="container mx-auto px-4 md:px-6">
    <div class="max-w-4xl mx-auto">

      <!-- ــــ النموذج ــــ -->
      <div class="no-print">

        <div class="bg-white rounded-3xl ring-1 ring-slate-200 p-6 md:p-8 mb-6">
          <h2 class="text-xl font-black text-primary flex items-center gap-2.5 mb-6">
            <i class="fas fa-circle-info text-accent"></i> المعطيات العامة
          </h2>
          <div class="grid gap-4 sm:grid-cols-2">
            <label class="block">
              <span class="block text-sm font-bold text-slate-600 mb-2">المؤسسة</span>
              <input type="text" x-model="f.school" placeholder="ثانوية…"
                     class="w-full rounded-xl border-2 border-slate-200 bg-white px-4 py-3 font-medium text-slate-800 focus:border-accent outline-none transition">
            </label>
            <label class="block">
              <span class="block text-sm font-bold text-slate-600 mb-2">الأستاذ(ة)</span>
              <input type="text" x-model="f.teacher" placeholder="الاسم الكامل"
                     class="w-full rounded-xl border-2 border-slate-200 bg-white px-4 py-3 font-medium text-slate-800 focus:border-accent outline-none transition">
            </label>
            <label class="block">
              <span class="block text-sm font-bold text-slate-600 mb-2">المادة</span>
              <input type="text" x-model="f.subject" placeholder="اللغة العربية · الرياضيات…"
                     class="w-full rounded-xl border-2 border-slate-200 bg-white px-4 py-3 font-medium text-slate-800 focus:border-accent outline-none transition">
            </label>
            <label class="block">
              <span class="block text-sm font-bold text-slate-600 mb-2">المستوى</span>
              <input type="text" x-model="f.level" placeholder="الرابعة ابتدائي · الثانية إعدادي…"
                     class="w-full rounded-xl border-2 border-slate-200 bg-white px-4 py-3 font-medium text-slate-800 focus:border-accent outline-none transition">
            </label>
            <label class="block">
              <span class="block text-sm font-bold text-slate-600 mb-2">الوحدة / المجزوءة</span>
              <input type="text" x-model="f.unit"
                     class="w-full rounded-xl border-2 border-slate-200 bg-white px-4 py-3 font-medium text-slate-800 focus:border-accent outline-none transition">
            </label>
            <label class="block">
              <span class="block text-sm font-bold text-slate-600 mb-2">عنوان الدرس</span>
              <input type="text" x-model="f.title"
                     class="w-full rounded-xl border-2 border-slate-200 bg-white px-4 py-3 font-medium text-slate-800 focus:border-accent outline-none transition">
            </label>
            <label class="block">
              <span class="block text-sm font-bold text-slate-600 mb-2">المدة</span>
              <input type="text" x-model="f.duration" placeholder="55 دقيقة"
                     class="w-full rounded-xl border-2 border-slate-200 bg-white px-4 py-3 font-medium text-slate-800 focus:border-accent outline-none transition">
            </label>
            <label class="block">
              <span class="block text-sm font-bold text-slate-600 mb-2">التاريخ</span>
              <input type="text" x-model="f.date" placeholder="مثال: 2 غشت 2026"
                     class="w-full rounded-xl border-2 border-slate-200 bg-white px-4 py-3 font-medium text-slate-800 focus:border-accent outline-none transition">
            </label>
          </div>
        </div>

        <div class="bg-white rounded-3xl ring-1 ring-slate-200 p-6 md:p-8 mb-6">
          <h2 class="text-xl font-black text-primary flex items-center gap-2.5 mb-3">
            <i class="fas fa-bullseye text-accent"></i> الكفاية والأهداف
          </h2>
          <p class="text-sm text-slate-500 leading-relaxed mb-6">
            صِغ الهدف بفعل <b>قابل للملاحظة</b> (يحسب · يصنّف · يحرر) لا بـ«يفهم» أو «يعرف»،
            فالفهم لا يُرى. راجع <a href="/maqalat/tasnif-bloom" class="text-primary font-bold">تصنيف بلوم</a>
            و<a href="/maqalat/kayfa-tabni-jadada" class="text-primary font-bold">كيف تبني جذاذة ناجحة</a>.
          </p>

          <label class="block mb-5">
            <span class="block text-sm font-bold text-slate-600 mb-2">الكفاية المستهدفة</span>
            <textarea x-model="f.competence" rows="2" placeholder="أن يكون المتعلم قادرًا على… في وضعية جديدة"
                      class="w-full rounded-xl border-2 border-slate-200 bg-white px-4 py-3 font-medium text-slate-800 focus:border-accent outline-none transition"></textarea>
          </label>

          <span class="block text-sm font-bold text-slate-600 mb-2">الأهداف التعلّمية</span>
          <template x-for="(o, i) in f.goals" :key="i">
            <div class="flex items-center gap-2 mb-2">
              <input type="text" :value="o" @input="f.goals[i] = $event.target.value"
                     placeholder="أن يميّز المتعلم بين…"
                     class="flex-1 rounded-xl border-2 border-slate-200 bg-white px-4 py-3 font-medium text-slate-800 focus:border-accent outline-none transition">
              <button type="button" @click="f.goals.splice(i, 1)" x-show="f.goals.length > 1"
                      aria-label="حذف الهدف"
                      class="w-12 h-12 shrink-0 rounded-xl bg-slate-100 text-red-600 hover:bg-slate-200 transition-colors">
                <i class="fas fa-xmark"></i>
              </button>
            </div>
          </template>
          <button type="button" @click="f.goals.push('')"
                  class="mt-2 inline-flex items-center gap-2 text-sm font-bold text-primary hover:gap-3 transition-all">
            <i class="fas fa-plus text-xs"></i> أضف هدفًا
          </button>

          <div class="grid gap-4 sm:grid-cols-2 mt-6">
            <label class="block">
              <span class="block text-sm font-bold text-slate-600 mb-2">المتطلبات القبلية</span>
              <textarea x-model="f.prereq" rows="3" placeholder="ما يجب أن يتقنه المتعلم قبل هذا الدرس"
                        class="w-full rounded-xl border-2 border-slate-200 bg-white px-4 py-3 font-medium text-slate-800 focus:border-accent outline-none transition"></textarea>
            </label>
            <label class="block">
              <span class="block text-sm font-bold text-slate-600 mb-2">الوسائل والدعامات</span>
              <textarea x-model="f.tools" rows="3" placeholder="الكتاب المدرسي · السبورة · وثائق…"
                        class="w-full rounded-xl border-2 border-slate-200 bg-white px-4 py-3 font-medium text-slate-800 focus:border-accent outline-none transition"></textarea>
            </label>
          </div>
        </div>

        <div class="bg-white rounded-3xl ring-1 ring-slate-200 p-6 md:p-8 mb-6">
          <h2 class="text-xl font-black text-primary flex items-center gap-2.5 mb-3">
            <i class="fas fa-list-ol text-accent"></i> مراحل الدرس
          </h2>
          <p class="text-sm text-slate-500 leading-relaxed mb-6">
            المراحل الأربع مقترحة سلفًا. <b>احجز وقتًا للاستثمار والتقويم</b> — هما أول ما
            يُضحّى به عند ضيق الوقت، وهما بالضبط لحظة التحقق من التعلم.
          </p>

          <template x-for="(s, i) in f.stages" :key="i">
            <div class="bg-slate-50 rounded-2xl p-5 mb-3">
              <div class="flex items-center gap-2 mb-3">
                <input type="text" :value="s.name" @input="f.stages[i].name = $event.target.value"
                       placeholder="اسم المرحلة"
                       class="flex-1 rounded-xl border-2 border-slate-200 bg-white px-4 py-2.5 font-bold text-slate-800 focus:border-accent outline-none transition">
                <input type="text" :value="s.time" @input="f.stages[i].time = $event.target.value"
                       placeholder="المدة"
                       class="w-20 shrink-0 rounded-xl border-2 border-slate-200 bg-white px-3 py-2.5 font-medium text-slate-800 focus:border-accent outline-none transition">
                <button type="button" @click="f.stages.splice(i, 1)" x-show="f.stages.length > 1"
                        aria-label="حذف المرحلة"
                        class="w-12 h-12 shrink-0 rounded-xl bg-white text-red-600 hover:bg-slate-100 transition-colors">
                  <i class="fas fa-xmark"></i>
                </button>
              </div>
              <div class="grid gap-3 sm:grid-cols-2">
                <textarea :value="s.teacher" @input="f.stages[i].teacher = $event.target.value" rows="3"
                          placeholder="نشاط الأستاذ"
                          class="w-full rounded-xl border-2 border-slate-200 bg-white px-4 py-3 text-sm font-medium text-slate-800 focus:border-accent outline-none transition"></textarea>
                <textarea :value="s.learner" @input="f.stages[i].learner = $event.target.value" rows="3"
                          placeholder="نشاط المتعلم"
                          class="w-full rounded-xl border-2 border-slate-200 bg-white px-4 py-3 text-sm font-medium text-slate-800 focus:border-accent outline-none transition"></textarea>
              </div>
            </div>
          </template>

          <div class="flex flex-wrap gap-3 mt-4">
            <button type="button" @click="f.stages.push({ name: '', time: '', teacher: '', learner: '' })"
                    class="inline-flex items-center gap-2 text-sm font-bold text-primary hover:gap-3 transition-all">
              <i class="fas fa-plus text-xs"></i> أضف مرحلة
            </button>
            <button type="button" @click="resetStages()"
                    class="inline-flex items-center gap-2 text-sm font-bold text-slate-500 hover:text-primary transition-colors">
              <i class="fas fa-rotate-right text-xs"></i> استرجع المراحل المقترحة
            </button>
          </div>

          <div class="grid gap-4 sm:grid-cols-2 mt-6">
            <label class="block">
              <span class="block text-sm font-bold text-slate-600 mb-2">التقويم</span>
              <textarea x-model="f.assess" rows="3" placeholder="كيف تتحقق أن الهدف تحقق فعلًا؟"
                        class="w-full rounded-xl border-2 border-slate-200 bg-white px-4 py-3 font-medium text-slate-800 focus:border-accent outline-none transition"></textarea>
            </label>
            <label class="block">
              <span class="block text-sm font-bold text-slate-600 mb-2">الامتداد / الواجب</span>
              <textarea x-model="f.homework" rows="3" placeholder="تثبيت لما تُدُرِّب عليه في القسم"
                        class="w-full rounded-xl border-2 border-slate-200 bg-white px-4 py-3 font-medium text-slate-800 focus:border-accent outline-none transition"></textarea>
            </label>
          </div>
        </div>

        <div class="flex flex-wrap gap-3 mb-10">
          <button type="button" @click="print()"
                  class="flex-1 bg-primary text-white py-4 rounded-xl font-black text-lg hover:bg-secondary transition-all shadow-lg shadow-primary/20">
            <i class="fas fa-print ml-2"></i> اطبع الجذاذة
          </button>
          <button type="button" @click="clear()"
                  class="bg-slate-100 text-slate-700 px-6 py-4 rounded-xl font-black hover:bg-slate-200 transition-colors">
            <i class="fas fa-eraser ml-2"></i> امسح الكل
          </button>
        </div>

        <h2 class="text-xl font-black text-slate-900 mb-4 flex items-center gap-2.5">
          <i class="fas fa-eye text-accent"></i> المعاينة
        </h2>
      </div>

      <!-- ــــ الجذاذة نفسها (هي ما يُطبع) ــــ -->
      <div class="bg-white rounded-3xl ring-1 ring-slate-200 p-6 md:p-10 article-body">

        <div class="flex flex-wrap items-start justify-between gap-4 mb-6">
          <div>
            <p class="font-bold text-slate-700" x-text="f.school || 'المؤسسة'"></p>
            <p class="text-sm text-slate-500" x-text="f.teacher ? 'الأستاذ(ة): ' + f.teacher : ''"></p>
          </div>
          <p class="text-sm text-slate-500" x-text="f.date"></p>
        </div>

        <h2 class="text-center" x-text="f.title || 'جذاذة درس'"></h2>

        <div class="table-wrap">
          <table>
            <tbody>
              <tr><th>المادة</th><td x-text="f.subject"></td><th>المستوى</th><td x-text="f.level"></td></tr>
              <tr><th>الوحدة</th><td x-text="f.unit"></td><th>المدة</th><td x-text="f.duration"></td></tr>
            </tbody>
          </table>
        </div>

        <h3>الكفاية المستهدفة</h3>
        <p x-text="f.competence || '—'"></p>

        <h3>الأهداف التعلّمية</h3>
        <ul>
          <template x-for="(o, i) in filled(f.goals)" :key="i">
            <li x-text="o"></li>
          </template>
        </ul>
        <p x-show="filled(f.goals).length === 0">—</p>

        <div class="table-wrap">
          <table>
            <tbody>
              <tr><th>المتطلبات القبلية</th><td x-text="f.prereq"></td></tr>
              <tr><th>الوسائل والدعامات</th><td x-text="f.tools"></td></tr>
            </tbody>
          </table>
        </div>

        <h3>مراحل الدرس</h3>
        <div class="table-wrap">
          <table>
            <thead>
              <tr><th>المرحلة</th><th>المدة</th><th>نشاط الأستاذ</th><th>نشاط المتعلم</th></tr>
            </thead>
            <tbody>
              <template x-for="(s, i) in f.stages" :key="i">
                <tr>
                  <td x-text="s.name"></td>
                  <td x-text="s.time"></td>
                  <td x-text="s.teacher"></td>
                  <td x-text="s.learner"></td>
                </tr>
              </template>
            </tbody>
          </table>
        </div>

        <h3>التقويم</h3>
        <p x-text="f.assess || '—'"></p>

        <h3>الامتداد / الواجب</h3>
        <p x-text="f.homework || '—'"></p>
      </div>

      <p class="mt-6 text-center text-sm text-slate-400 font-bold no-print">
        <i class="fas fa-lock text-xs"></i>
        كل ما تكتبه يبقى في متصفحك — لا يُرسَل إلى أي خادم ولا يُخزَّن.
      </p>

      <div class="mt-10 bg-white rounded-3xl ring-1 ring-slate-200 p-6 md:p-8 article-body no-print">
        <h2>نصائح تجعل الجذاذة نافعة لا شكلية</h2>
        <ol>
          <li><b>ابدأ من النهاية.</b> حدّد الكفاية ودليل تحققها أولًا، ثم اختر الأنشطة —
              وإلا خرجتَ بأنشطة ممتعة لا تخدم الكفاية.</li>
          <li><b>هدف أو هدفان للحصة.</b> الجذاذة المكتظة تجعلك تسابق الزمن فتقطع الأنشطة قبل استخلاصها.</li>
          <li><b>لا تُضحِّ بالاستثمار والتقويم.</b> هما أول ما يُختصر عند الضغط، وبهما وحدهما
              تعرف من فهم ومن لم يفهم.</li>
          <li><b>اكتب ملاحظاتك بعد الحصة</b> على الهامش: ما نجح، وأين تعثّروا، وما استغرق وقتًا أطول.
              هذا وحده ما يراكم خبرة مهنية عبر السنوات.</li>
        </ol>
        <div class="note-info">
          <b>تحقّق من فهمك النظري:</b> <a href="/ikhtibarat/takhtit/">اختبار التخطيط والجذاذة</a> —
          أسئلة عن المنهاج والأهداف وتصنيف بلوم ومراحل الدرس، بتصحيح فوري.
        </div>
      </div>

    </div>
  </div>
</div>

<script>
/** مولّد الجذاذة — كل شيء داخل المتصفح، بلا تخزين ولا إرسال. */
function jadada() {
  /** المراحل المقترحة: بنية درس شائعة تُعدَّل بحرية */
  function defaults() {
    return [
      { name: 'وضعية الانطلاق', time: '10 د', teacher: 'يطرح وضعية تستدعي المكتسب القبلي وتخلق الحاجة إلى الجديد.', learner: 'يستحضر مكتسباته ويصوغ فرضيات.' },
      { name: 'بناء التعلمات',  time: '25 د', teacher: 'ينظّم العمل ويلاحظ ويتدخل بقدر عند التعثر.',              learner: 'يشتغل فرديًا أو في مجموعات ويبني المفهوم.' },
      { name: 'الاستثمار',      time: '10 د', teacher: 'يقترح وضعية جديدة لتشغيل ما بُني.',                       learner: 'يوظّف ما تعلّمه في سياق مختلف.' },
      { name: 'التقويم',        time: '10 د', teacher: 'يقدّم مهمة قصيرة تكشف مدى التحقق.',                       learner: 'ينجز فرديًا ويصحّح ذاتيًا.' }
    ];
  }

  function blank() {
    return {
      school: '', teacher: '', subject: '', level: '', unit: '',
      title: '', duration: '', date: '',
      competence: '', goals: [''], prereq: '', tools: '',
      stages: defaults(), assess: '', homework: ''
    };
  }

  return {
    f: blank(),

    /** الأهداف غير الفارغة فقط — حتى لا تظهر أسطر خالية في المعاينة */
    filled(list) {
      return list.filter(function (x) { return x && x.trim() !== ''; });
    },

    resetStages() { this.f.stages = defaults(); },

    clear() {
      if (window.confirm('سيُمسح كل ما كتبتَه. متأكد؟')) { this.f = blank(); }
    },

    print() { window.print(); }
  };
}
</script>

<?php
require __DIR__ . '/partials/app-cta.php';
require __DIR__ . '/partials/footer.php';
